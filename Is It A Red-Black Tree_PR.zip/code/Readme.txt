Using a compiler or IDE(vscode, devc++, vs) to compile the the source code "RBT.c".

Execute the executable file and test it.

If failing to compile the source code, use the 'RBT.exe' in this folder to test the program.